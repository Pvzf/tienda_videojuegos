import { Component } from '@angular/core';
import { GameService } from '../services/game.service';

@Component({
  selector: 'app-add-game',
  templateUrl: './add-game.component.html',
  standalone: false,
  styleUrl: './add-game.component.scss',
})
export class AddGameComponent {
  title = '';
  price = 0;
  description = '';

  constructor(private gameService: GameService) {}

  onAddGame() {
    this.gameService.addGame(this.title, this.price, this.description);
    this.title = '';
    this.price = 0;
    this.description = '';
  }
}