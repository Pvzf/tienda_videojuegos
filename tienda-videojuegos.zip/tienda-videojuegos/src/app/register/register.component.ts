import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: false,
  templateUrl: './register.component.html',
  styleUrl: './register.component.scss'
})
export class RegisterComponent {
  email = '';
  password = '';
  username = '';
  error = false;

  constructor(public auth: AuthService, private router: Router) {}

  register() {
    this.error = !this.auth.register(this.email, this.password, this.username);
    if (!this.error) {
      this.router.navigate(['/games']);
    }
  }
}