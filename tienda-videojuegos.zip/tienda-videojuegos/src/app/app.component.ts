import { Component, OnInit } from '@angular/core';
import { AuthService } from './services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  standalone: false
})

export class AppComponent {
  title(title: any) {
    throw new Error('Method not implemented.');
  }
  games: any[] = [];
  constructor(public auth: AuthService, private router: Router) {}

  get username(): string {
    const user = this.auth.getCurrentUser();
    return user?.username || '';
  }

  isLoggedIn(): boolean {
    return this.auth.isLoggedIn();
  }

  logout() {
    this.auth.logout();
    this.router.navigate(['/login']);
  }

  ngOnInit() {
    if (this.isLoggedIn()) {
      this.router.navigate(['/home']);
    }
  }
}
