import { Component } from '@angular/core';

@Component({
  selector: 'app-protected',
  standalone: false,
  templateUrl: './protected.component.html',
  styleUrl: './protected.component.scss'
})
export class ProtectedComponent {

}
