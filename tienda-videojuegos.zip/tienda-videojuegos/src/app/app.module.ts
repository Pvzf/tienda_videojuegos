import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { GamesComponent } from './games/games.component';
import { AddGameComponent } from './add-game/add-game.component';
import { LogoutComponent } from './logout/logout.component';
import { ProtectedComponent } from './protected/protected.component';
import { AppRoutingModule } from './app-routing.module';

import { AuthService } from './services/auth.service';
import { GameService } from './services/game.service';
import { AuthGuard } from './guards/auth.guard';
import { PopularGamesComponent } from './pages/popular-games/popular-games.component';
import { TopDownloadsComponent } from './pages/top-downloads/top-downloads.component';
import { ComingSoonComponent } from './pages/coming-soon/coming-soon.component';
import { GameDetailComponent } from './pages/game-detail/game-detail.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'home', component: HomeComponent },
  { path: 'games', component: GamesComponent },
  { path: 'add-game', component: AddGameComponent },
  { path: 'protected', component: ProtectedComponent, canActivate: [AuthGuard] },
  { path: 'logout', component: LogoutComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    HomeComponent,
    AddGameComponent,
    LogoutComponent,
    ProtectedComponent,
    GamesComponent,
    LoginComponent,
    PopularGamesComponent,
    TopDownloadsComponent,
    ComingSoonComponent,
    GameDetailComponent
  ],
  imports: [
    
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    RouterModule.forRoot(routes)
  ],
  providers: [AuthService, GameService, AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule {}
