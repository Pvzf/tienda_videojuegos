import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss'
})
export class LoginComponent {
  email = '';
  password = '';
  error = false;

  constructor(public auth: AuthService, private router: Router) {}

  onLogin() {
    this.error = !this.auth.login(this.email, this.password);
    if (!this.error) {
      this.router.navigate(['/home']);
    }
  }
}
