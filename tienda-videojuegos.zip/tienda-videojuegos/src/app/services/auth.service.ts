import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})

export class AuthService {
  login(email: string, password: string): boolean {
    const user = localStorage.getItem(email);
    if (user && JSON.parse(user).password === password) {
      localStorage.setItem('currentUser', email);
      return true;
    }
    return false;
  }

  register(email: string, password: string, username: string): boolean {
    if (localStorage.getItem(email)) return false;
    localStorage.setItem(email, JSON.stringify({ email, password, username }));
    return true;
  }

  logout(): void {
    localStorage.removeItem('currentUser');
  }

  isLoggedIn(): boolean {
    return localStorage.getItem('currentUser') !== null;
  }

  getCurrentUser(): any {
    const email = localStorage.getItem('currentUser');
    if (!email) return null;
    return JSON.parse(localStorage.getItem(email) || '{}');
  }
}
