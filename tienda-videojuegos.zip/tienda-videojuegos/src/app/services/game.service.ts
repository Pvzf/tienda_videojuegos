import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GameService {
  games: any[] = [
    { title: 'Minecraft', price: 399.99, description: 'el mejor juego'},
    { title: 'Grand Theft Auto', price: 319.99, description: 'el mejor juego' },
    { title: 'Cuphead & The Delicious Last Course', price: 469.00, description: 'el mejor juego'},
    { title: 'Slender: The Arrival', price: 349.99, description: 'el mejor juego'}
  ];
  
  getGames() {
    return this.games;
  }

  getGameById(id: number) {
    return this.games.find(g => g.id === id);
  }

  addGame(title: string, price: number, description: string) {
    const id = this.games.length + 1;
    this.games.push({ id, title, price, description });
  }
}