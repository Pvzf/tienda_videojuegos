import { Component, OnInit } from '@angular/core';
import { GameService } from '../services/game.service';


@Component({
  selector: 'app-games',
  templateUrl: './games.component.html',
  standalone: false,
  styleUrl: './games.component.scss'
})
export class GamesComponent implements OnInit {
  games: any[] = [];

  constructor(private gameService: GameService) {
    this.games = this.gameService.getGames();
  
  }

  ngOnInit() {
    this.games = this.gameService.getGames();
  }
}
