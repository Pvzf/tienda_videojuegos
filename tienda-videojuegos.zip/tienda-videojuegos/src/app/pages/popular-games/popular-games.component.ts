import { Component } from '@angular/core';

@Component({
  selector: 'app-popular-games',
  standalone: false,
  templateUrl: './popular-games.component.html',
  styleUrl: './popular-games.component.scss'
})
export class PopularGamesComponent {

}
