import { Component } from '@angular/core';

@Component({
  selector: 'app-top-downloads',
  standalone: false,
  templateUrl: './top-downloads.component.html',
  styleUrl: './top-downloads.component.scss'
})
export class TopDownloadsComponent {

}
